history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostnamectl set-hostname TPServer
hostname
apt update && apt upgrade -y
nano /etc/apt/sources.list
apt install nano -y
vi /etc/apt/sources.list
apt update
apt full-upgrade -y
cat /etc/os-release
reboot
cat /etc/os-release
apt install nano -y
apt install openssh-server -y
systemctl status ssh
ls /root
tar -xzf /root/Material_Adicional_TPVMCA.tar.gz -C /root
ls /root
ls /root/Material_Adicional_TPVMCA
mkdir -p /root/.ssh
cp /root/Material_Adicional_TPVMCA/clave_publica.pub /root/.ssh/authorized_keys
chmod 700 /root/.ssh
chmod 600 /root/.ssh/authorized_keys
nano /etc/ssh/sshd_config
systemctl restart ssh
systemctl status ssh
apt install apache2 -y
apt install php libapache2-mod-php -y
systemctl status apache2
cp /root/Material_Adicional_TPVMCA/index.php /var/www/html/
cp /root/Material_Adicional_TPVMCA/logo.png /var/www/html/
ls /var/www/html/
apt install mariadb-server -y
systemctl status mariadb
mariadb < /root/Material_Adicional_TPVMCA/db.sql
mariadb
ip a
ip route
nano /etc/network/interfaces
systemctl restart networking
ip a
shutdown now
journalctl -xb
journalctl -xb | grep -i failed
cat /etc/fstab
nano /etc/fstab
reboot
