#!/bin/bash

# Opción de ayuda
if [ "$1" == "-help" ]; then
	echo "Uso: backup_full.sh <origen> <destino>"
	echo "Ejemplo: backup_full.sh /var/log /backup_dir"
	exit 0
fi

# Validar que se pasaron los argumentos
if [ -z "$1" ] || [ -z "$2" ]; then
	echo "Error: debes indicar origen y destino."
	echo"Usá -help para mas información."
	exit 1
fi

ORIGEN=$1
DESTINO=$2

# Validar que origen y destino existen
if [ ! -d "$ORIGEN" ]; then
	echo "Error: el directorio origen $ORIGEN no existe."
	exit 1
fi

if [ ! -d "$DESTINO" ]; then
	echo "Error: el directorio destino $DESTINO no existe."
	exit 1
fi

# Generar nombre del archivo con fecha
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")
ARCHIVO="${NOMBRE}_bkp_${FECHA}.tar.gz"

# Ejecutar el backup
tar -czf "$DESTINO/$ARCHIVO" "$ORIGEN"

echo "Backup realizado: $DESTINO/$ARCHIVO"
